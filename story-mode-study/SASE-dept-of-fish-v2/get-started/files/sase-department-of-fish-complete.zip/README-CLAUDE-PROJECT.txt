FortiSASE — Department of Fish — Complete Claude Project Bundle
================================================================

Every file below sits at the top level of this zip — no subfolders. Drop the
whole lot into a fresh Claude Project's Knowledge tab.

  00-START-HERE.txt                     Upload order + start commands.
  01-PROJECT-INSTRUCTIONS.txt           Paste into the project's Custom Instructions.
  02-DEPARTMENT-SETUP.txt               Setting, canonical locations, applications.
  03-CHARACTERS.txt                     Samwise, Junior, Señor, Dr Eleanor, Fysh + support cast.
  04-STUDY-PLAN-SASE-NSE5-NSE7.txt      The 41-episode curriculum (NSE 5 + NSE 7).
  05-MODE-SOCRATIC.txt                  Default teaching mode.
  06-MODE-REVIEW.txt                    Recap mode.
  07-LAB-INDEX.txt                      Optional labs.
  08-LEARNER-TRACKING.txt               Confidence tracking template.
  09-SESSION-OUTPUT-TEMPLATES.txt       Session-summary + knowledge-register format.
  10-BLUEPRINT-COVERAGE-MAP.txt         Blueprint objective coverage per episode.
  11-SOURCE-REGISTER.txt                Authoritative sources.
  MANIFEST.txt                          Machine-readable file list.

You also need the Fortinet NSE 5 FortiSASE Core Administrator blueprint and
the FortiSASE 26 Core Administrator study guide (plus the NSE 7 Architect
materials for Seasons 4–6) — grab those from your usual Fortinet source.

HOW TO USE
1. Open claude.ai, create a new Project.
2. Paste 01-PROJECT-INSTRUCTIONS.txt into Custom Instructions.
3. Upload every file in this zip into Knowledge.
4. Send:  Start SASE-S1E01.  (or Start SASE-S4E01. for the NSE 7 entry.)
