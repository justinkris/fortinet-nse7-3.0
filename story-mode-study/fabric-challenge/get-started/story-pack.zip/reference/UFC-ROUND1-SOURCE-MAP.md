# UFC Round 1 Source Map

This file reproduces the supplied challenge scope in structured Markdown for study planning.

## 8.0-1 — World 2 Boardroom — 450 pts
- Authorize devices in FAZ — 50
- FortiMQ Connector — 50
- Indicators — 50
- Fabric Feeds — 50
- Webfilter profile — 100
- Policy — 100
- FMQ in action — Optional — 50

## 8.0-2 — CISO Office — 350 pts
- Hybrid key exchange — 100
- Hybrid Key verification — 50
- SSL enforcement — 100
- SSL enforcement verification — 50
- Question — 50

## 8.0-3 — NOC Room — 400 pts
- Sanctioned/Unsanctioned classification — 100
- Application Control — Optional — 100
- Custom Tag — 50
- Tag policy — 100
- Application Classification in-action — 50

## 8.0-4 — SOC Room — 400 pts
- FortiOS access hardening — 100
- Reverse SSL VIP — 150
- Firewall policy to SSL VIP Virtual server — 100
- SSL VIP validation — 50

## FortiDLP-1 — Cubicles — 300 pts
- Onboarding an agent — 100
- Setup SaaS-apps — 100
- Policy groups — 100

## FortiDLP-2 — Server Room — 700 pts
- AI Policy — 100
- Policy action — 100
- Test the AI Policy — 100
- File download policy — 100
- Test the file download policy — 100
- File origin policy — 100
- Test the file origin policy — 100

## FortiDLP-3 — Lunch Area — 300 pts
- Question 1 — 50
- Question 2 — 50
- Question 3 — 50
- Question 4 — 50
- Question 5 — 50
- Question 6 — 50

## OT-1 — OT-Factory Meeting Room — 200 pts
- Enable OT Features on FortiGate — 100
- OT Custom IPS: MSSQL EXE File Insertion — 100

## OT-2 — OT-Factory Meeting Room — 1250 pts
- SOC Preparation - Create an Alert Handler to detect Initial Compromise — 100
- Configure the Correlation Sequence for the Alert Handler — 100
- Configure the Correlation Criteria for the Alert Handler — 100
- SOC Preparation - Create Alerts Handler for Correlate Lateral Movement to OT Hosts — Optional — 100
- SOC Preparation - Detect HTTP Malicious Payload Transfer Between Internal Segments — 100
- SOC Preparation - Create Alerts Handler for detect Lateral Tool Transfer via MSSQL Table Data — 100
- SOC Preparation - Create Alerts Handler for Suspicious xp_cmdshell Execution Detected — 100
- SOC Preparation - Create Event Correlation Rule for detect RTU Commands from unusual devices — 100
- SOC Preparation - Enable FortiAI for User — 100
- Q1 Patient Zero Identification — Optional — 50
- Q2 Correlation Operator — Optional — 50
- Q3 Lateral Movement Port — Optional — 50
- Q4 SQL Infiltration Pattern — Optional — 50
- Q5 Command Execution Signature — Optional — 50
- Q6 Pivot Host Identification — Optional — 50
- Q8 RTU Target — Optional — 50

## OT-3 — Production Floor — 300 pts
- OT Segmentation IT LAN — 100
- OT Segmentation OT-Process — 100
- OT Segmentation Disable Catch All — 100

## OT-4 — Server Room — 400 pts
- OT Granular IT-to-OT Remote Access — 100
- OT Critical Protocol Inspection (IEC-104 & SQL) — 100
- OT Application Control Baseline (Per Zone) — 100
- OT IPS Visibility without Disruption — 100

## Source Limitation

The supplied source does not include the official answers or procedures for these objectives.
