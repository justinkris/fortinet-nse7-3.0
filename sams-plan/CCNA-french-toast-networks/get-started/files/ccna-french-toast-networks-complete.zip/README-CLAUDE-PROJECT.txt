CCNA — French Toast Networks — Complete Claude Project Bundle
==============================================================

Every file below sits at the top level of this zip — no subfolders. Drop the
whole lot into a fresh Claude Project's Knowledge tab.

  00-README.txt                            Program purpose + usage.
  01-CCNA-master-study-plan.txt            Overview, learning model, depth rule, seasons.
  02-agency-french-toast-networks.txt      FTN organisation profile.
  03-characters.txt                        Aussie, Étienne, Camille, Rafa, Madame Colette.
  04-world-and-story-continuity.txt        Story-world continuity.
  05-teaching-mode.txt                     Paste into Custom Instructions.
  06-review-mode.txt                       Season-recap mode.
  07-lab-mode.txt                          Optional hands-on lab mode.
  08-knowledge-register-template.txt       Per-episode register.
  09-session-summary-template.txt          Per-episode summary.
  10-master-mind-map.md                    CCNA 200-301 mind map.
  11-blueprint-session-mapping.csv         Blueprint objective → episode.
  12-season-and-episode-guide.txt          All 58 episodes with scope.
  13-optional-lab-catalogue.txt            26 hands-on labs.
  14-exam-readiness-framework.txt          Exam-readiness self-assessment.
  15-continuity-rules.txt                  What carries between sessions.
  16-session-prompt-template.txt           Session-prompt template.

Also useful: the Cisco CCNA 200-301 v1.1 exam blueprint (from cisco.com) and
your preferred study reference (OCG, Boson, etc.) — those are not included.

HOW TO USE
1. Open claude.ai, create a new Project.
2. Paste 05-teaching-mode.txt into Custom Instructions.
3. Upload every file in this zip into Knowledge.
4. Send:  Start EP-01.
