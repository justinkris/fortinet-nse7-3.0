NSE 4 — Department of Sea Creatures — Complete Claude Project Bundle
======================================================================

Every file below sits at the top level of this zip — no subfolders. Drop the
whole lot into a fresh Claude Project's Knowledge tab.

  01-PROJECT-INSTRUCTIONS.txt        Paste into the project's Custom Instructions.
  02-DEPARTMENT-SETUP.txt            Setting, initial topology, core cast.
  03-STUDY-PLAN-NSE4.txt             The 34-episode curriculum.
  04-MODE-SOCRATIC.txt               Default teaching mode.
  05-MODE-REVIEW.txt                 Recap mode.
  06-LAB-INDEX-NSE4.txt              Optional labs.
  07-LEARNER-TRACKING.txt            Confidence tracking template.
  08-SESSION-OUTPUT-TEMPLATES.txt    Session-summary + knowledge-register format.
  00-START-HERE.txt                  Upload order + start commands.
  PACKAGE-MANIFEST.json              Machine-readable file list.

You also need the Fortinet NSE 4 blueprint and the FortiOS 7.6 Administrator
study guide — those are not included; grab them from your usual Fortinet source.

HOW TO USE
1. Open claude.ai, create a new Project.
2. Paste 01-PROJECT-INSTRUCTIONS.txt into Custom Instructions.
3. Upload every file in this zip into Knowledge.
4. Send:  Start FISH-S1E01.
